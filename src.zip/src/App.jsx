import { Route } from 'react-router-dom';
import './App.css';
import Dashboard from './Components/Booking/Dashboard';
import Routing from './Route/Route';

function App() {
  return (
    <div className="App">
      {/* <Dashboard/> */}
      <Routing/>
    </div>
  );
}

export default App;
